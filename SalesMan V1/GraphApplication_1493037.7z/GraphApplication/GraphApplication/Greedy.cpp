#include "pch.h"
#include "Graph.h"

// SalesmanTrackGreedy =========================================================

CTrack SalesmanTrackGreedy(CGraph& graph, CVisits &visits)
{
	CTrack cami(&graph);
	list<CVertex*> candidats;

	/* for (list<CVertex*>::iterator it = visits.m_Vertices.begin(); it != visits.m_Vertices.end(); it++) {

	}*/

	for (list<CVertex*>::iterator it = std::next(visits.m_Vertices.begin(), 1); it != std::prev(visits.m_Vertices.end(), 1); it++) {
		candidats.push_back(*it);
	}

	CVertex* vActual = visits.m_Vertices.front();

	while (!candidats.empty()) {
		DijkstraQueue(graph, vActual);

		double minDist;
		CVertex* vMinDist;
		minDist = candidats.front()->m_DijkstraDistance;
		vMinDist = candidats.front();

		for (CVertex* v : candidats) {
			if (v->m_DijkstraDistance < minDist) {
				vMinDist = v;
				minDist = v->m_DijkstraDistance;
			}
		}
		string edgeNameStr = vMinDist->m_DijkstraPrev->m_Name;

		const char* edgeNameChar = edgeNameStr.c_str();

		CEdge* prevEdge = graph.FindEdge(edgeNameChar);

		cami.AddLast(prevEdge);

		CVertex* aux = vMinDist;
		CTrack auxTrack(&graph);
		if (vMinDist->m_DijkstraPrev == cami.m_Edges.back()) {

		}
	}
	
	
	return CTrack(&graph);
}
