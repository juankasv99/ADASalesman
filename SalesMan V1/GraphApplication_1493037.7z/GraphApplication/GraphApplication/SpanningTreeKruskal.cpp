#include "pch.h"
#include "Graph.h"
#include <vector>
#include <queue>
using namespace std;


// =============================================================================
// SpanningTreeKruskal =========================================================
// =============================================================================


CSpanningTree SpanningTreeKruskal(CGraph& graph)
{
	return CSpanningTree(&graph);
}

